$(function(){

	$('.rotater.imgs').slides({
		play: 5000,
		preload: true,
		preloadImage: 'images/general/loading.gif',
		hoverPause: true,
		pause: 1,
		effect: 'fade',
		fadeSpeed: 500
	});

	$('.rotater.text').slides({
		play: 12000,
		preload: true,
		hoverPause: true,
		pause: 1,
		effect: 'fade',
		fadeSpeed: 500
	});

$('.slider').bxSlider({
    mode: 'fade',
    auto:true,
	controls:true,
	pager:false,
	captions: false,

	});
	
$('.forgotpassword').click(function(){
	$('.topheader .row #forgotPassword').hide();
	$('#forgotPassword').show();
	$('#logindropdowncontainer').hide();
});

$('#loginlink').mouseenter(function () {
    $('.topheader .row #forgotPassword').hide();
});
$('.container').click(function(){
	$('.topheader .row #forgotPassword').hide();
});


});

$(function() {
			var pull 		= $('#pull');
				menu 		= $('.nav_right');
				menuHeight	= menu.height();

			$(pull).on('click', function(e) {
				e.preventDefault();
				menu.slideToggle();
			});

			$(window).resize(function(){
        		var w = $(window).width();
        		if(w > 767 && menu.is(':hidden')) {
        			menu.removeAttr('style');
        		}
    		});
		});


