﻿$(document).ready(function () {
    $('#user_name,#header_username').keypress(function (e) {
        if (e.which === 32)
            return false;
    });

});
 function doAjaxCall(url,data,showLoading,callback){
	if (showLoading){
	   $('.loadingDiv').show();
	   }
	   $.ajax({
	   url: url,
	   type: "POST",
	   data: data,
	   cache: false,
	   success: function(html){
		callback(html);
	   if (showLoading){
            $('.loadingDiv').hide();
	   }
   },
   error: function(request, status, error){
        //alert(request);
        //alert(error);
        //alert(status);
        //console.log(request.responseText);
   }
   });
 };
 
function formReset(keeper){

		keeper.find('input[type="text"],input[type="password"],textarea').val('');
		keeper.find('textarea.ckeditor').val('');
		keeper.find('input[type="checkbox"]').prop('checked',false);
		keeper.find('input[type="checkbox"]').removeAttr('checked');

} 
$(document).ready(function(){
	 /*add function */
		var base_url = $('#base_url').val();
	  $('#expressLogin').off('click').on('click',function(){
			$('.login_error').hide('fade');
			var button_val = $(this).val();
			$(this).val('Processing');
			$(this).attr('disabled','disabled');
			var $this = $(this);
			var url =  $(this).closest('form').attr('action'); 
			var data = $(this).closest('form').serialize();  
			var keeper = $(this).closest('form');
			  doAjaxCall(url,data,false,function(html){
                                        //console.log(html);
                                        //alert(html);
					if(html == 0){
						$('.login_error').show().text('Username Or Password Does Not Match ..!');
						
					
					}
					if(html == 2){
						$('.login_error').show().text('Admin Deactivate Your account.');
					}
					if(html == 3){
						$('.login_error').show().text('Admin Suspend Your account.');
					}
					if(html == 8){
						// redirect at advertiser dashboard
						
						window.location.href=base_url+"advertiser";
					}
					if(html == 9){
					// redirect at publisher dashboard
						window.location.href=base_url+"publisher";
					}
					$this.val(button_val);
					$this.removeAttr('disabled');
				});
		});
		
					
		// add new user 
	  $('#addNewUserButton').click(function () {
	      $('.alert-success').hide('fade');
	      $('.alert-error').hide('fade');
	      $('.alert-info').hide('fade');
				if($('#add_user').valid()){
				    $('.sign_up.alert-error').html('');
				var button_val = $(this).val();
				$(this).val('Please Wait');
				$(this).attr('disabled','disabled');
				var $this 	= $(this);
				var url  	= $(this).closest('form').attr('action'); 
				var data  	= $(this).closest('form').serialize();  
				var keeper 	= $(this).closest('form');
			
				  doAjaxCall(url,data,false,function(html){
                                                //console.log(html);
						//alert(html);
						if(html == 1){
						    $('.sign_up.alert-success').text("Your Request Has Been Sent Successfully. We'll get back to you within 48 hours.").show('fade');
							formReset(keeper);
						}
						if(html == 2){
							$('.sign_up.alert-error').text('User Name Already Exist. Please Enter Another Name.').show('fade');
						}
						if(html == 3){
						    $('.sign_up.alert-error').text('Email Already Exist. Please Enter Another Email.').show('fade');
						}
						if(html == 4){
						    $('.sign_up.alert-error').text('Please Choose at Least One Category.').show('fade');
						}
						
						$this.val(button_val);
						$this.removeAttr('disabled');
					});
			}
		});
	 /*end add function */

	 // add new user 
	  $('#sendInquiery').click(function () {
	      $('.alert-success').hide('fade');
	      $('.alert-error').hide('fade');
	      $('.alert-info').hide('fade');
				if($('#user_inquires').valid()){
				   
				var button_val = $(this).val();
				$(this).val('Sending');
				$(this).attr('disabled','disabled');
				var $this 	= $(this);
				var url  	= $(this).closest('form').attr('action'); 
				var data  	= $(this).closest('form').serialize();  
				var keeper 	= $(this).closest('form');
			
				  doAjaxCall(url,data,false,function(html){
						$this.val('Mail Sent');
						//$this.removeAttr('disabled');
						 $('.customer.alert-success').text('Your Inquiry Has Been Sent Successfully.').show('fade');
							formReset(keeper);
					});
			}
		});
	 /*end add function */
	 
	 $('#resetPass').off('click').on('click',function(){
			$('.login_error').hide('fade');
			var button_val = $(this).val();
			$(this).val('Sending Mail');
			$(this).attr('disabled','disabled');
			var $this = $(this);
			var url =  $(this).closest('form').attr('action'); 
			var data = $(this).closest('form').serialize();  
			var keeper = $(this).closest('form');
			  doAjaxCall(url,data,false,function(html){
					if(html==0){
					    $('.login_error').show('fade').text('Email Address Does Not Match.');
							$this.val(button_val);
							$this.removeAttr('disabled');
					}else{
						$this.val('Mail Sent');
					}
				});
		});
	
	$('.gf-radio.options input[type="radio"]').click(function(){
	checkMessage();
	});	
	checkMessage();
	
});
function checkMessage(){
		var userChoice	=	$('.gf-radio.options input[type="radio"]:checked').val();
		if(userChoice==1){
			$('#adminmsg').html('Select one or more to advertise in:<b class="req_field">*</b>');
		}
		if(userChoice==2){
			$('#adminmsg').html('Select one or more types of traffic you would like to send:<b class="req_field">*</b>');
		}

}





