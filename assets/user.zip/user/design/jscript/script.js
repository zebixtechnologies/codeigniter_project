/*
	The code below is designed to run on all pages of the site, all
	functionality below should be made page specific, so check for the 
	existance of the pages body class that you are targeting
*/

$(document).ready(function() {
/******************** GENERAL JS FOR ALL PAGES ************************/
	
	/* the following functions handle the login window in the header */
	
	// hide the login window when user clicks anywhere in the body
	/*$('body').click(function(){
		if($('#logindropdowncontainer').css('display') == 'block'){	$('#logindropdowncontainer').fadeOut();	}
	});
	
	// stops the click event attached to the body from firing within the login window and the login link in the header
	$("#loginlink,#logindropdowncontainer").click(function(e) { e.stopPropagation(); });
	// click event to toggle showing and hiding the login window when the login link is clicked
	$('#loginlink').click(function(){ $('#logindropdowncontainer').fadeToggle(); });
	*/
	
	// submit is triggered when the Enter Key is pressed in the password field

	$('#header_password').on('keypress', function(e) {
		var code = (e.keyCode ? e.keyCode : e.which);
		if(code == 13) { $('#login').submit(); }
		else{ return true; }
	});

	// submit is triggered when the Login button is clicked
	$('#loginbutton').click(function(){
		if($('#header_username').val() == '' && $('#header_password').val() == ''){
			$('.login_error').hide();
			$('#login_error_both').show();
			clearTimeout(login_out_timer);
			return false;
		}else if($('#header_username').val() == ''){
			$('.login_error').hide();
			$('#login_error_username').show();
			clearTimeout(login_out_timer);
			return false;
		}else if($('#header_password').val() == ''){
			$('.login_error').hide();
			$('#login_error_password').show();
			clearTimeout(login_out_timer);
			return false;
		}else{
			$('#login').submit();
			return false;
		}
	});
	
	login_in_timer = null;
	login_out_timer = null;
	
	$('#loginlink,#logindropdowncontainer').on({
		mouseenter:
			function(){
				clearTimeout(login_out_timer);
				login_in_timer = setTimeout(function(){ $('#logindropdowncontainer').fadeIn(); },150);
			},
		mouseleave:
			function(){
				if($('#header_username:focus,#header_password:focus').size() == 0){
					clearTimeout(login_in_timer);
					clearTimeout(login_out_timer);
					login_out_timer = setTimeout(function(){ $('#logindropdowncontainer').fadeOut(); },666);
				}
			}
		}
    );
    
    $('#header_username,#header_password,#remember').on({
		focus:
			function(){
				clearTimeout(login_out_timer);
			},
		blur:
			function(){
				clearTimeout(login_in_timer);
				clearTimeout(login_out_timer);
				login_out_timer = setTimeout(function(){ $('#logindropdowncontainer').fadeOut(); },666);
			}
	});
	
	$('#remember').bind("click", function() {
		if( $(this).is(":checked") ) {
			$('#remember-me-info').show();
		}
		else {
			$('#remember-me-info').hide()
		}
	});
	
	// bind 'login' and provide a simple callback function 
	/*$('#login').ajaxForm({
		dataType:'json',
		success:function(json)
			{
				$('#loginerrors_default,#loginerrors').hide();
				if(json.errors){ 
					$('#loginerrors').show();
					$('#loginerrors').html(json.errors);
				}else if(json.login_error){
					$('#loginerrors').show();
					$('#loginerrors').html('<p>'+json.login_error+'</p>');
				}else if(json.redirect_url){
					window.location = json.redirect_url;
				}else{
					$('#loginerrors_default').show();
				}
			},
		error: function(){ $('#loginerrors_default').show(); }
	});*/
	
	if(!Modernizr.input.placeholder){
		$('[placeholder]').focus(function() {
			var input = $(this);
			if (input.val() == input.attr('placeholder')) {
				input.val('');
				input.removeClass('placeholder');
			}
		}).blur(function() {
			var input = $(this);
			if (input.val() == '' || input.val() == input.attr('placeholder')) {
				input.addClass('placeholder');
				input.val(input.attr('placeholder'));
			}
		}).blur();
		$('[placeholder]').parents('form').submit(function() {
			$(this).find('[placeholder]').each(function() {
				var input = $(this);
				if (input.val() == input.attr('placeholder')) {
					input.val('');
				}
			});
		});
	}
});
