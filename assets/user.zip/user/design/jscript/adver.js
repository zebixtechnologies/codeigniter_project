
function formReset(keeper){

		keeper.find('input[type="text"],input[type="password"],textarea').val('');
		keeper.find('textarea.ckeditor').val('');
		keeper.find('input[type="checkbox"]').prop('checked',false);
		keeper.find('input[type="checkbox"]').removeAttr('checked');

} 
$(document).ready(function(){
	 /*add function */
		var base_url = $('#base_url').val();
	  $('#updateadverProfile').click(function(){
	  		if($('#adv_profile_view').valid()){
	  			var button_val = $(this).val();
			$(this).val('Cheking');
			$(this).attr('disabled','disabled');
			var $this = $(this);
			var url =  $(this).closest('form').attr('action'); 
			var data = $(this).closest('form').serialize();  
			var keeper = $(this).closest('form');
			var msg,type,title;
			  doAjaxCall(url,data,false,function(html){
					if(html == 1){
							msg = 'Password Has Been Change Successfully .';
							type = 'success';
							title = 'Update Profile';
					}else{
							msg = 'Your current Password does not match.';
							type = 'error';
							title = 'Update Profile Failed';
					}
					
					$.pnotify({
								title: title,
								text: msg,
								type: type
							});
					$this.val(button_val);
					$this.removeAttr('disabled');
				});
	  		}
			
		});
		
					
		// add new user 
		$('#addNewUserButton').click(function(){
				if($('#add_user').valid()){
				$('.sign_up.error').html('');
				var button_val = $(this).val();
				$(this).val('Please Wait');
				$(this).attr('disabled','disabled');
				var $this 	= $(this);
				var url  	= $(this).closest('form').attr('action'); 
				var data  	= $(this).closest('form').serialize();  
				var keeper 	= $(this).closest('form');
			
				  doAjaxCall(url,data,false,function(html){
						
						if(html == 1){
							$('.sign_up.success').text('Your Request Has Been Sent Successfully.');
							formReset(keeper);
						}
						if(html == 2){
							
							$('.sign_up.error').text('User Name Already Exist. Please Enter Another Name.');
						}
						if(html == 3){
							$('.sign_up.error').text('Email Already Exist. Please Enter Another Email.');
						}
						
						$this.val(button_val);
						$this.removeAttr('disabled');
					});
			}
		});
	 /*end add function */
});


