(function() {
	var displayTests = ["table", "table-caption", "table-cell", 
	"table-column", "table-column-group", "table-footer-group", 
	"table-header-group", "table-row", "table-row-group"];
	
	var rules = document.createElement("div").style;

	for (var c=0; c<displayTests.length; c++) {
		var testValue = displayTests[c];
		Modernizr.addTest("display" + testValue, function() {
			try {
				rules.display = testValue;
				return rules.display == testValue;
			} catch (e) {
				return false;
			}
		})
	}
}());
