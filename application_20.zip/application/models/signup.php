<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */

class signup_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	
	public function usersignup()
	{
		$name = $this->security->xss_clean($this->input->post('name'));
		$company = $this->security->xss_clean($this->input->post('company'));
		$email 	= $this->security->xss_clean($this->input->post('email'));
		$categories	= $this->security->xss_clean($this->input->post('cateories'));
		 $cat=  implode(',',$categories);
		$phone=$this->security->xss_clean($this->input->post('phone'));
		$isActive='1';
		$this->db->select('*');
		$this->db->where('email',$email);
		$query = $this->db->get('user_profile');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$user['name'] = $category_name;
		$user['company'] = $category_detail;
		$user['website']= $parent_category;
		$user['isActive']= $isActive;
		$user['requesTime']= time();
		$user['categories']= $cat;
		$this->db->insert('user_profile',$user);
		return true;
		}
	}
	
	// sign in page accroding user role
	public function usersign()
	{
		$userId = $this->security->xss_clean($this->input->post('username'));
		$password = $this->security->xss_clean($this->input->post('password'));
		//$pwd=md5($password);
		//echo"<script>alert($userId)</script>";
		$userId='rajkumar@sumedhasoftech.com';
		$password='123456';
		$this->load->model('business_model');
		$pwd=$this->business_model->getMD5Password($password);
		$this->db->select('*');
		$this->db->where('email',$userId);
		$this->db->where('password',$pwd);
		$query = $this->db->get('user_profile');
		if($query->num_rows > 0){
			return $query->row();
		
		}else{
				return false; 
		}
		
	}
	

}
