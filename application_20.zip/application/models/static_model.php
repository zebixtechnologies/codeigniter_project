<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */

class static_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function getCMSPage($pageId) {
		$this -> db -> select('*');
		$this -> db -> where('pageid', $pageId);
		$this -> db -> from('static_page');
		$query = $this -> db -> get();
		return $query -> result();

	}

	public function contactusmail() {
		$data['fname'] = $this -> security -> xss_clean($this -> input -> post('fname'));
		$data['lname'] = $this -> security -> xss_clean($this -> input -> post('lname'));
		$data['user_phone'] = $this -> security -> xss_clean($this -> input -> post('phone'));
		$data['user_email'] = $this -> security -> xss_clean($this -> input -> post('email'));
		$data['user_comment'] = $this -> security -> xss_clean($this -> input -> post('comment'));

		$data['{base_url}'] = $this -> config -> base_url();
		$data['Site_name'] = SITE_NAME;
		$data['site_number'] = SITE_CUSTOMER_CARE;

		require_once ("mailer/Email.php");
		$emailSender = new Email();
		
		$emailSender -> SendEmail('contactus', $data, ADMIN_MAIL, ADMIN_MAIL, ADMIN_MAIL_PASSWORD, SITE_NAME, 'Contact Us Mail');
		$return=TRUE;
	}

}
