<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */

class advertiser_model extends CI_Model {
	function __construct() {
		parent::__construct();
		$this->load->model('business_model');
	}

	public function getAdvDashboardInfo() {
		
		// get user id from session 
		$userID= $this->session->userdata($userlogin['user_id']);
		$balance=$this->business_model->getBlance($userID);
		$query=$this->db->select('SELECT count(*) as activeAds FROM ad_info where isActive=1 and userId='.$userID);
		$val= $query->row();
		$adv_dashboard = array(
                'balance' => $balance,
                'activeads' => $val->activeAds
                );
		
		return $adv_dashboard;
	}
	
	public function getReport(){
		
		$userID= $this->session->userdata($userlogin['user_id']);
		$this->db->select('*');
		$this->db->where('userId',$userID);
		$query = $this->db->get('ad_info');
		 return $query->result();
		
	}
	public function getFilteredReport(){
		
		$duration;
		$adID;
		$min;
		$max;
		$userID= $this->session->userdata($userlogin['user_id']);
		$this->db->select('*');
		$this->db->where('userId',$userID);
		$this->db->where('userId',$userID);
		$this->db->where('clickTime between $min and $max');
		$query = $this->db->get('ad_status');
		 return $query->result();
		
		
	}
	 public function addAd()
	{
		
		$ad['adName'] = $this->security->xss_clean($this->input->post('adname'));
		$ad['adTitle'] = $this->security->xss_clean($this->input->post('adtitle'));
		$ad['siteUrl'] = $this->security->xss_clean($this->input->post('siteurl'));
		$ad['color'] = $this->security->xss_clean($this->input->post('color'));
		$ad['bannerImage'] = $this->security->xss_clean($this->input->post('bannerimage'));
		$ad['state'] = $this->security->xss_clean($this->input->post('state'));
		$ad['bannerBackground'] = $this->security->xss_clean($this->input->post('bannerbackground'));
		$ad['created']=date();
		$ad['userId']= $this->session->userdata($userlogin['user_id']);
		$this->db->insert('ad_info',$ad);
		return true;
		
	}
	public function modifyAd()
	{
		$adID = $this->security->xss_clean($this->input->post('adid'));
		$ad['adName'] = $this->security->xss_clean($this->input->post('adname'));
		$ad['adTitle'] = $this->security->xss_clean($this->input->post('adtitle'));
		$ad['siteUrl'] = $this->security->xss_clean($this->input->post('siteurl'));
		$ad['color'] = $this->security->xss_clean($this->input->post('color'));
		$ad['bannerImage'] = $this->security->xss_clean($this->input->post('bannerimage'));
		$ad['state'] = $this->security->xss_clean($this->input->post('state'));
		$ad['bannerBackground'] = $this->security->xss_clean($this->input->post('bannerbackground'));
		$this->db->where('adId',$adID);
			return ($this->db->update('ad_info',$ad)) ? true : false;
		
	}
	public function listAds()
	{
		$userId= $this->session->userdata($userlogin['user_id']);
		
		$this->db->select('*');
		$this->db->from('ad_info');
		$this->db->where('user_id',$userId);
		$query = $this->db->get();
		return $query->result();
	}
	public function modifyAccountInfo()
	{
		$userId= $this->session->userdata($userlogin['user_id']);
		$usr['userName'] = $this->security->xss_clean($this->input->post('userName'));
		$usr['company'] = $this->security->xss_clean($this->input->post('company'));
		$usr['website'] = $this->security->xss_clean($this->input->post('website'));
		$usr['phone'] = $this->security->xss_clean($this->input->post('phone'));
		$usr['email'] = $this->security->xss_clean($this->input->post('email'));
		$usr['categories'] = $this->security->xss_clean($this->input->post('category'));
		$this->db->where('userId',$userId);
			return ($this->db->update('user_profile',$usr)) ? true : false;
		
		
	}
	public function changePassword()
	{
		$userId= $this->session->userdata($userlogin['user_id']);
		$password = $this->security->xss_clean($this->input->post('password'));
		$this->load->model('business_model');
		$pwd=$this->business_model->getMD5Password($password);
		$this->db->set('password', $pwd, FALSE);
		$this->db->where('userId',$userId);
			return ($this->db->update('user_profile')) ? true : false;
		
	}
	

}
