<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */

class publisher_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}

	public function getDashboardInfo() {
		
	}

}
