<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */
 
class advertiser_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
  
    public function getadvertisers(){
        $this->db->select('up.*,( select count(adId) from ad_info  where ad_info.userId = up.userId  AND  ad_info.isActive = 1 AND ad_info.isApproved = 1 AND ad_info.isDeleted = 0 ) as total_activeAds,(select sum(credit)-sum(debit) FROM accounts WHERE  userId = up.userId) as balance');
        $this->db->where('up.isAccepted',1);
        $this->db->where('up.isDeleted',0);
        $this->db->where('up.isActive',1);
        $this->db->where('up.userType',1);
        $this->db->from('user_profile up');
        $query = $this->db->get();
 // echo $this->db->last_query();
  return $query->result();
    }


 public function getuseradv($userId){
  $this->db->select('ad_i.*,us_p.userName,us_p.adverFromIcon');
  $this->db->from('ad_info ad_i');
  $this->db->join('user_profile us_p','us_p.userId = ad_i.userId');
  $this->db->where('ad_i.userId',$userId);
  $this->db->where('ad_i.isDeleted',0);
  $this->db->order_by('ad_i.bid_ppc','desc');
  $query = $this->db->get();
  return $query->result();
 }
  
  public function adminformIcon($userId)
	{
		$this->db->select('*');
		$this->db->from('user_profile');
		$this->db->where('userId',$userId);
		$query = $this->db->get();
		return $query->result();
	}
 public function getadvinfo($getadvdetail){
  $this->db->select('ad_i.*,us_p.userName,adv_s.stateName,adv_c.name as countryName');
  $this->db->from('ad_info ad_i');
  $this->db->join('user_profile us_p','us_p.userId = ad_i.userId');
  $this->db->join('state adv_s','adv_s.stateId = ad_i.state','left outer');
  $this->db->join('country adv_c','adv_c.countryId = adv_s.countryId');
  $this->db->where('ad_i.adId',$getadvdetail);
  $this->db->where('ad_i.isDeleted',0);
  $this->db->order_by('ad_i.bid_ppc','desc');
  $query = $this->db->get();
  return $query->result();
 }
 public function getStates(){
  $this->db->select('*');
  $this->db->from('state');
  $this->db->where('isActive',1);
  $this->db->order_by('stateName');
  $query = $this->db->get();
  return $query->result();
 }

 public function getCategory(){
  $this->db->select('*');
  $this->db->from('categories');
  $this->db->where('isActive',1);
  $this->db->order_by('categoryName');
  $query = $this->db->get();
  return $query->result();
 }
 public function updateBannerImage($imageNAme,$small_img_path,$adId,$Field)// 1 for banner //2 for banner background
 {
  if($Field==1){
  $ban['bannerImage']    = $imageNAme;
  $ban['small_bannerImage'] = $small_img_path;
  }
  if($Field==2){
  $ban['bannerBackground'] = $imageNAme;
  $ban['banner_background_small '] = $small_img_path;
  }
  $this->db->where('adId',$adId);
  $this->db->update('ad_info',$ban);
  return true;
 }
 public function updateImageSize()
 {
  $src = $this->security->xss_clean($this->input->post('imageSrc'));
  $adID = $this->security->xss_clean($this->input->post('adID'));
  $field = $this->security->xss_clean($this->input->post('field'));// 1 for banner //2 for banner background
  $this->db->select('*');
  $this->db->from('ad_info');
  $this->db->where('adId',$adID);
  $query = $this->db->get();
  $result = $query->result();
  foreach( $result as $res) {
   if($field==1){
    
    $banner = $res->bannerImage;
   }
   if($field==2){
    $banner = $res->bannerBackground;
   }
  }
  $targ_w = $_POST['w'];
  $targ_h = $_POST['h'];
  $jpeg_quality = 100;
  $img_r = imagecreatefromjpeg($src);
  $dst_r = ImageCreateTrueColor( $targ_w, $targ_h );
  imagecopyresampled($dst_r,$img_r,0,0,$_POST['x'],$_POST['y'],
  $targ_w,$targ_h,$_POST['w'],$_POST['h']);
  imagejpeg($dst_r,$banner,$jpeg_quality);
  return $result;
 }
 public function updateAdvData()
 {
  $ad['adName']  		= $this->security->xss_clean($this->input->post('adName'));
  $ad['adTitle']  		= $this->security->xss_clean($this->input->post('adTitle'));
  $ad['color']  		= $this->security->xss_clean($this->input->post('color'));
  $ad['siteUrl']  		= $this->security->xss_clean($this->input->post('siteUrl'));
  $ad['adIcon_display'] = $this->security->xss_clean($this->input->post('adIcon'));
  $ad['adtype'] 		= $this->security->xss_clean($this->input->post('adtype'));
	
 $ad['adTitle_display']  = $this->security->xss_clean($this->input->post('display_title'));
  $ad['adDiscription_display']  = $this->security->xss_clean($this->input->post('description_display'));
  $state 		 = $this->security->xss_clean($this->input->post('state'));
  $stateId	= substr($state, 0, strpos($state, "-"));
			$stateName	= substr($state,strpos($state, "-")+1);
			$ad['state'] = $stateId;
			$ad['stateName'] = $stateName;
  $ad['categoryId']  = $this->security->xss_clean($this->input->post('category'));
  $ad['formId']  = $this->security->xss_clean($this->input->post('form_name'));
  $editId  = $this->security->xss_clean($this->input->post('editId'));
  $this->db->where('adId',$editId);
  $this->db->update('ad_info',$ad);
  return true;
 }
 
		public function updateAdverBalance(){
                    $ad['memo']  = $this->security->xss_clean($this->input->post('memo'));
                    $ad['userId']  = $this->security->xss_clean($this->input->post('userId'));
                    $option = $this->security->xss_clean($this->input->post('option'));
                    $ad['transactionTime']  = time();
                    $ad['comment']  = 5;
                    if($option == "credit"){
                        $ad['credit']  = $this->security->xss_clean($this->input->post('amount'));
                    }else if($option == "debit"){
                        $ad['debit']  = $this->security->xss_clean($this->input->post('amount'));
                    }
                    $this->db->insert('accounts',$ad);
                    return true;
               }
			 
		public function getallforms()
			 {
				  $this->db->select('*');
				  $this->db->from('customeform');
				  $this->db->where('isActive',1);
				  $this->db->order_by('formName');
				  $query = $this->db->get();
				  return $query->result();
			 }
	 
 public function insertNewAD()
		{
			
			$ad['adName'] 			= $this->security->xss_clean($this->input->post('adName'));
			$ad['adTitle'] 			= $this->security->xss_clean($this->input->post('adTitle'));
			//$ad['color'] 			= $this->security->xss_clean($this->input->post('color'));
			$ad['siteUrl'] 			= $this->security->xss_clean($this->input->post('siteUrl'));
			$userId 				= $this->security->xss_clean($this->input->post('currentUser'));
			$ad['userActivation'] 	= 1;
			$ad['isActive'] 		= 1;
			$ad['requesTime'] 		= time();
			$categoryId				= $this->security->xss_clean($this->input->post('category'));
			if($categoryId==''){
				echo 5;
			}else{
				$ad['categoryId']  = $categoryId;
			}
			
			$state					= $this->security->xss_clean($this->input->post('state'));
			
			if($state == ''){
				return 4;
			}else{
			$stateId	= substr($state, 0, strpos($state, "-"));
			$stateName	= substr($state,strpos($state, "-")+1);
			$ad['state'] = $stateId;
			$ad['stateName'] = $stateName;
			}
			
			$ad['bid_ppc']			= $this->security->xss_clean($this->input->post('bid'));
			$adtype		= $this->security->xss_clean($this->input->post('adtype'));
			
			if($adtype==null || $adtype ==''){
				return 6;
			}else{
			if($adtype ==1){
				$ad['adTitle_display']			= $this->security->xss_clean($this->input->post('display_title'));
				$ad['adDiscription_display']	= $this->security->xss_clean($this->input->post('description_display'));
				$adIcon_display			= $this->security->xss_clean($this->input->post('adIcon'));
				if($adIcon_display == null || $adIcon_display ==''){
					return 7;
				}else{
				$ad['adIcon_display']			= $this->security->xss_clean($this->input->post('adIcon'));
				}
			}else{
			
			
			/*
					$bannerBackground		= $this->security->xss_clean($this->input->post('banner_background'));
					if($bannerBackground ==''){
						return 2; // banner back not uploaded 
					}else{
						$ad['bannerBackground']	 = 	$bannerBackground;
						$smallImagePath = str_replace('uploads/banners','uploads/banners/small',$ad['bannerBackground']);
						$ad['banner_background_small']= $smallImagePath;
					}
					
					$bannerImage		= $this->security->xss_clean($this->input->post('newbanner'));
					if($bannerImage ==''){
						return 3;
					}else{
						$ad['bannerImage']	 = 	$bannerImage;
						$smallImagePath_banner = str_replace('uploads/banners','uploads/banners/small',$ad['bannerImage']);
						$ad['small_bannerImage']= $smallImagePath_banner;
					}
					$ad['small_bannerImage']= $this->security->xss_clean($this->input->post('newbanner'));
					
				*/
			}
			
			$ad['adType'] = $adtype;
			}
			$ad['userId']			= $userId;
			$this->db->insert('ad_info',$ad);
			return 1;
		} 
                
                //Code By sarvesh
                
    public function getManageBanner($user_id) {
        //echo $user_id;
        $this->db->select('*');
        $this->db->from('user_profile');
        $this->db->where('userId',$user_id);
        $query = $this->db->get();
        return  $query->result();
    }
    public function getManageBannerUploadLogo($logo_name,$user_id) {
        $this->db->where('advertiser_id', $user_id);
        $this->db->update('manage_banner', $logo_name);
    }
    public function getManageBannerUpdateData($user_id) {
        $this->db->select('*');
        $this->db->from('manage_banner');
        $this->db->where('advertiser_id',$user_id);
        $query = $this->db->get();
        return  $query->result();
    }
    public function getManageBannerUploadContent($content_data,$user_id) {
        $this->db->where('advertiser_id', $user_id);
        $this->db->update('manage_banner', $content_data);
    }
    public function getManageBannerCheckAdvertiserId($user_id) {
        $this->db->select('*');
        $this->db->from('manage_banner');
        $this->db->where('advertiser_id',$user_id);
        $query = $this->db->get();
        return  $query->result();
    }
    public function getManageBannerInsertAdvertiserId($userId) {
        $this->db->insert('manage_banner',$userId);
       
    }
    //by neeta
    public function getCategoryWithBanner($catId=  NULL){
        $sql = "select * from categories LEFT OUTER JOIN manage_form_banner ON categories.categoryId = manage_form_banner.cat_id WHERE isActive=1";
        if($catId != NULL){
            $sql .= " and categoryId = $catId";
        }
        $query = $this->db->query($sql);
        return $query->result();
    }
    public function getcategary($catId){
        $this->db->select('*');
		$this->db->where('categoryId',$catId);
		$query = $this->db->get('categories');
		return $query->result();
    }
    public function getCategoryBanner($catId){
        $this->db->select('*');
        $this->db->where('cat_id',$catId);
        $query = $this->db->get('manage_form_banner');
        return $query->result();
    }
    public function insertCatBanner($catBanner){
        $this->db->insert('manage_form_banner',$catBanner);
        $this->db->insert_id();
    }
    public function updateCatBanner($catBanner,$catId){
        $this->db->where('cat_id',$catId);
        $this->db->update('manage_form_banner',$catBanner);
    }
    public function deleteBannerOfCategory($catId){
        $sql = "DELETE FROM manage_form_banner WHERE cat_id = $catId";
        $this->db->query($sql);
    }
    //End
}
?>