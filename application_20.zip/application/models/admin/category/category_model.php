<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */
 
class category_model extends CI_Model{
    function __construct(){
        parent::__construct();
		//$this->getCategoryTreeForParentId();
    }
    
  public function getCategoryTreeForParentId($parent_id = 0) {
  $categories = array();
  $this->db->from('categories');
  $this->db->where('parentCategory', $parent_id);
  $result = $this->db->get()->result();
  foreach ($result as $mainCategory) {
    $category = array();
    $category['id'] = $mainCategory->categoryId;
    $category['name'] = $mainCategory->categoryName;
    $category['parent_id'] = $mainCategory->parentCategory;
    $category['sub_categories'] = $this->getCategoryTreeForParentId($category['id']);
    $categories[$mainCategory->categoryId] = $category;
  }
  echo '<pre>';
  print_r($categories);
  echo '</pre>';
}
    
	public function getcategaryInfo($isActive){
        $this->db->select('*');
		//$this->db->where('parentCategory',$parentId);
		$this->db->where('isActive',$isActive);
		$query = $this->db->get('categories');
		return $query->result();
    }
	public function getcategary($catId){
        $this->db->select('*');
		$this->db->where('categoryId',$catId);
		$query = $this->db->get('categories');
		return $query->result();
    }
	public function subcategory($parentId){
        $this->db->select('*');
		$this->db->where('parentCategory',$parentId);
		$query = $this->db->get('categories');
		return $query->result();
    }
	public function getallcategary(){
        $this->db->select('c.*,c_dup.categoryName as parentName');
		$this->db->from('categories c');
		$this->db->group_by('categoryId');
		$this->db->join('categories c_dup','c_dup.categoryId=c.parentCategory','left outer');
		$query = $this->db->get();
		return $query->result();
    }
	public function deleteCategory($catId){
		$this->db->where('categoryId',$catId);
		$this->db->or_where('parentCategory',$catId);
		return($this->db->delete('categories')) ? true:false;
    }
	
	public function insertNewCategory(){
		$category_name 		= $this->security->xss_clean($this->input->post('category_name'));
		$parent_category 	= $this->security->xss_clean($this->input->post('parent_category'));
		$category_detail 	= $this->security->xss_clean($this->input->post('category_detail'));
		$isActive 			= $this->security->xss_clean($this->input->post('isActive'));
		$this->db->select('*');
		$this->db->where('categoryName',$category_name);
		$query = $this->db->get('categories');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$cat['categoryName'] 		= $category_name;
		$cat['categoryDescription'] = $category_detail;
		$cat['parentCategory']		= $parent_category;
		$cat['isActive']			= $isActive;
		$cat['created']			= time();
		$cat['lastUpdate']			= time();
		$this->db->insert('categories',$cat);
		return true;
		}
	}
	public function updateCategory(){
		$category_name 		= $this->security->xss_clean($this->input->post('category_name'));
		$parent_category 	= $this->security->xss_clean($this->input->post('parent_category'));
		$category_detail 	= $this->security->xss_clean($this->input->post('category_detail'));
		$isActive 			= $this->security->xss_clean($this->input->post('isActive'));
		$editId 			= $this->security->xss_clean($this->input->post('editId'));
		$this->db->select('*');
		$this->db->where('categoryName',$category_name);
		$this->db->where('categoryId !=', $editId );
		$query = $this->db->get('categories');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$cat['categoryName'] 		= $category_name;
		$cat['categoryDescription'] = $category_detail;
		$cat['parentCategory']		= $parent_category;
		$cat['isActive']			= $isActive;
		$cat['lastUpdate']			= time();
		
		$this->db->where('categoryId',$editId);
		$this->db->update('categories',$cat);
		
		return true;
		}
	}
	
	// to get all parent categories (raj)
	 public function getparentcategaryInfo($isActive){
        $this->db->select('*');
		//$this->db->where('parentCategory',$parentId);
		$this->db->where('isActive',$isActive);
		$this->db->where('parentCategory','0');
		$query = $this->db->get('categories');
		return $query->result();
    }
    public function updateBidPrice($catId){
        $catBidPriceByAdmin = $cat["minbidprice"] = $this->security->xss_clean($this->input->post('bidprice'));
        $this->db->where("categoryId",$catId);
        $this->db->update("categories",$cat);
      //print_r($catBidPriceByAdmin);
        // update each advertiser when admin updates bidprice of any categroy.
        
        
           
           

            //	1. get all users
           $advs = array();
           $query=$this->db->query("SELECT userId,name,activecategory,bidprice,email FROM user_profile where userType = 1" );
           $results = $query->result();
           //print_r($results);
           // 2. get bidprice of advertiser
           //$updateAdv = array();
           foreach ($results as $adv){
                    $isForUpdate = false;
                    $updateString = "";
                    $comma = "";
                    $catstr = $adv->bidprice;
                   // print_r($catstr);
                    $catPriceArr = strlen($catstr) > 0 ? explode(",", $catstr) : array();
                    foreach($catPriceArr as $cp){
                        $catpr = isset($cp) && strlen($cp) > 0 ? explode(":", $cp) : NULL;
                        $cat = isset($catpr[0]) ? $catpr[0] : NULL;
                        $pr = isset($catpr[1]) ? $catpr[1] : NULL;
                        //print_r($pr);
                        if(isset($cat) && isset($pr)){
                            // 3. check admin_updated_category
                            if($cat == $catId){
                                //4. now check user bidprice for that category.
                               // print_r($catBidPriceByAdmin);
                              // print_r($pr);
                               if($catBidPriceByAdmin > $pr){
                                   $pr = $catBidPriceByAdmin;
                                  // print_r($pr);
                                   $isForUpdate = true;
                                   // 5 if user's bid price is less than cateogory's bid price then do update.
                                   //$updateAdv[] = $adv;
                               }
                            }
                            $updateString .= $comma . "$cat:$pr";
                            $comma = ",";
                        }
                    }
                    
                    // also update active category price for user [7/18/2014]
                    $comma = "";
                    $updateAcString = "";
                    $catstr = $adv->activecategory;
                   // print_r($catstr);
                    $catPriceArr = strlen($catstr) > 0 ? explode(",", $catstr) : array();
                    foreach($catPriceArr as $cp){
                        $catpr = isset($cp) && strlen($cp) > 0 ? explode(":", $cp) : NULL;
                        $cat = isset($catpr[0]) ? $catpr[0] : NULL;
                        $pr = isset($catpr[1]) ? $catpr[1] : NULL;
                        //print_r($pr);
                        if(isset($cat) && isset($pr)){
                            // 3. check admin_updated_category
                            if($cat == $catId){
                                //4. now check user bidprice for that category.
                               // print_r($catBidPriceByAdmin);
                              // print_r($pr);
                               if($catBidPriceByAdmin > $pr){
                                   
                                   $pr = $catBidPriceByAdmin;
                                  // print_r($pr);
                                   $isForUpdate = true;
                                   // 5 if user's bid price is less than cateogory's bid price then do update.
                                   //$updateAdv[] = $adv;
                               }
                            }
                            $updateAcString .= $comma . "$cat:$pr";
                            $comma = ",";
                        }
                    }
                    
                  //print_r($updateString);
                    if($isForUpdate){
                        $this->updateAdvBidPrice($adv->userId, $updateString,$updateAcString);
                    }
                }
        return true;
    }
    private function updateAdvBidPrice($advId,$bidPriceString,$updateAcString){
         //print_r($bidPriceString);
        $bid["bidprice"] = $bidPriceString;
        $bid["activecategory"] = $updateAcString;
      // print_r($bid["bidprice"]);
       //print_r($bid);
        $this->db->where("userId",$advId);
        $this->db->update("user_profile",$bid);
    }
    
    //by ravindra
    public function updatecatisActive($catId,$act){
        $catisActive['isActive'] = $act;
        $this->db->where('categoryId',$catId);
	$this->db->update('categories',$catisActive);
//        echo $this->db->last_query();
		
		return true;
        
    }
    
}
?>