<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */

class adv_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function getAdvpendingReq() {
        $this->db->select('a_i.*,u_p.userName,u_p.userType,ct.categoryName');
        $this->db->where('a_i.isApproved', 0);
        $this->db->where('a_i.isDeleted', 0);
        $this->db->from('ad_info a_i');
        $this->db->join('user_profile u_p', 'a_i.userId = u_p.userId');
        $this->db->join('categories ct', 'a_i.categoryId = ct.categoryId');
        $this->db->where('u_p.isActive', 1);
        $this->db->where('u_p.isDeleted', 0);
        $this->db->where('u_p.isAccepted', 1);
        $this->db->order_by('requesTime');
        $query = $this->db->get();
        return $query->result();
    }

    /*     * ******************************* */
    /* START OVER CLICKS CALCULATION */
    /*     * ****************************** */

    public function getoverClickOfDay() {
        $result = array();
        $i = 1;
        $click_limit = $this->getClickLimit();
        $from = time();
        $this->db->select('ai.*,u_p.userName');
        $this->db->from('ad_info ai');
        $this->db->join('user_profile u_p', 'ai.userId=u_p.userId');
        $this->db->where('ai.isApproved', 1);
        $this->db->where('ai.isDeleted', 0);
        $query = $this->db->get();
        foreach ($query->result() as $info) {
            $to = $from - ($i * 24 * 60 * 60);
            $response = $this->getoverClickSpecificTime($info->adId, $from, $to);



            foreach ($response as $respo) {
                $same_clicks = $respo->same_clicks;
                $ipaddress = $respo->ipaddress;

                if ($click_limit <= $same_clicks) {
                    $result[$i - 1]['ipaddress'] = $ipaddress;
                    $result[$i - 1]['same_clicks'] = $same_clicks;
                    $result[$i - 1]['from'] = $from;
                    $result[$i - 1]['to'] = $to;
                    $result[$i - 1]['adId'] = $info->adId;
                    $result[$i - 1]['userName'] = $info->userName;
                    $result[$i - 1]['userId'] = $info->userId;
                    $result[$i - 1]['adName'] = $info->adName;
                    $result[$i - 1]['adTitle'] = $info->adTitle;
                    $result[$i - 1]['small_bannerImage'] = $info->small_bannerImage;
                }
            }
            $from = $to;
            $i++;
        }


        return $result;
    }

    public function getClickLimit() {
        $this->db->select('maxClickLimit');
        $this->db->from('setting_ad_limit');
        $query = $this->db->get();
        $row = $query->row();
        return $row->maxClickLimit;
    }

    public function getoverClickSpecificTime($adId, $from, $to) {
        $this->db->select('count(*) as same_clicks,ipaddress');
        $this->db->from('ad_status');
        $this->db->where('adId', $adId);
        $this->db->where('clickTime <=', $from);
        $this->db->where('clickTime >=', $to);
        $this->db->where('isClicked', 1);
        $this->db->group_by('ipaddress');
        $query = $this->db->get();
        return $query->result();
    }

    /*     * ******************************* */
    /* END OVER CLICKS CALCULATION   */
    /*     * ****************************** */

    public function getAdvReq($adId) {
        $this->db->select('a_i.*,u_p.userName,u_p.userType,u_p.email,ct.categoryName,s.stateName');
        $this->db->where('a_i.isApproved', 0);
        $this->db->where('a_i.adId', $adId);
        $this->db->from('ad_info a_i');
        $this->db->join('user_profile u_p', 'a_i.userId = u_p.userId');
        $this->db->join('categories ct', 'a_i.categoryId = ct.categoryId');
        $this->db->join('state s', 's.stateId = a_i.state');
        $query = $this->db->get();
        return $query->result();
    }

    public function updateAdVApproval($adId, $mail_massage) {
        $cat['isApproved'] = 1;
        $cat['formId'] = $this->security->xss_clean($this->input->post('adFrom'));
        $cat['replyMail'] = $mail_massage;
        $cat['approvalTime'] = time();
        $this->db->where('adId', $adId);
        $this->db->update('ad_info', $cat);
        return true;
    }

    public function updateAdvReply($adId, $mail_massage) {

        $cat['replyMail'] = $mail_massage;
        $this->db->where('adId', $adId);
        $this->db->update('ad_info', $cat);
        return true;
    }

    public function refadReq($adId) {
        $cat['isApproved'] = 2;
        $this->db->where('adId', $adId);
        $this->db->update('ad_info', $cat);
        return true;
    }

    public function getadsList() {
        $this->db->select('a_i.*,s.stateName');
        $this->db->from('ad_info a_i');
        $this->db->join('state s', 'a_i.state = s.stateId', 'left outer');
        $this->db->where('a_i.isDeleted', 0);
        $this->db->where('a_i.isApproved', 1);
        $this->db->where('a_i.isActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    public function getadTrackRecords($adId) {
        $this->db->select('a_i.*,s.stateName,c.categoryName');
        $this->db->from('ad_info a_i');
        $this->db->join('state s', 'a_i.state = s.stateId', 'left outer');
        $this->db->join('ad_status a_s', 'a_s.adId = a_i.adId', 'left outer');
        $this->db->join('categories c', 'c.categoryId = a_i.categoryId', 'left outer');
        $this->db->where('a_i.isDeleted', 0);
        $this->db->where('a_i.isApproved', 1);
        $this->db->where('a_i.isActive', 1);
        $this->db->where('a_i.adId', $adId);


        $query = $this->db->get();

        return $query->result();
    }

    public function getallClicks($adId) {
        $this->db->select('a_s.*,(select credit from accounts where adStatusId = a_s.adStatusId and  userId = a_s.publisherId and comment != 3 and debit=0) as credit,(select debit from accounts where adStatusId = a_s.adStatusId and  userId = a_s.advertiserId and comment != 3 and credit=0) as debit,a_i.adName,u_p.userName as PublisherName,u_pp.userName as advertiserName,s.stateName');
        $this->db->from('ad_status a_s');
        $this->db->join('ad_info a_i', 'a_i.adId = a_s.adId');
        $this->db->join('user_profile u_p', 'u_p.userId = a_s.publisherId');
        $this->db->join('user_profile u_pp', 'u_pp.userId = a_s.advertiserId');
        $this->db->join('state s', 's.stateId = a_s.stateId', 'left outer');
        $this->db->where('a_s.adId', $adId);
        $this->db->order_by('a_s.created', 'desc');
        $this->db->where('a_s.isAdminRollBack', 0);
        $this->db->where('a_s.isClicked', 1);
        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }

    public function getAdvClickLimit() {
        $this->db->select('*');
        $this->db->from('setting_ad_limit');
        $query = $this->db->get();
        return $query->result();
    }

    public function rollBackTransaction($adStatusId) {
        $this->db->select('*');
        $this->db->from('accounts');
        $this->db->where('adStatusId', $adStatusId);
        $query = $this->db->get();
        foreach ($query->result() as $info) {
            if ($info->debit != 0 && $info->debit != NULL) {
                $debitAmount = $info->debit;
                $debitedUser = $info->userId;
                $credit['credit'] = $debitAmount;
                $credit['userId'] = $debitedUser;

                $credit['transactionTime'] = time();
                $credit['adStatusId'] = $adStatusId;
                $credit['memo'] = 'Admin Roll Back This Transaction.';
                $credit['comment'] = 3;
                $this->db->insert('accounts', $credit);
            }
            if ($info->credit != 0 && $info->credit != NULL) {
                $creditAmount = $info->credit;
                $creditedUser = $info->userId;
                $adminProfit = $info->admin_profile;
                $debit['debit'] = $creditAmount;
                $debit['userId'] = $creditedUser;
                $debit['transactionTime'] = time();
                $debit['adStatusId'] = $adStatusId;
                $debit['memo'] = 'Admin Roll Back This Transaction.';
                $debit['comment'] = 3;
                $debit['admin_profile'] = 0 - $adminProfit;
                $this->db->insert('accounts', $debit);
            }
        }
        $trans['isAdminRollBack'] = 1;
        $this->db->where('adStatusId', $adStatusId);
        $this->db->update('ad_status', $trans);
        return true;
    }

    public function saveSetting() {
        $setting['maxClickLimit'] = $this->security->xss_clean($this->input->post('max_clicks'));
        $this->db->update('setting_ad_limit', $setting);
        return TRUE;
    }

    public function saveCommisonSetting() {
        $setting['commission'] = $this->security->xss_clean($this->input->post('commission_rate'));
        $this->db->update('setting_admin_commission', $setting);
        return TRUE;
    }

    public function savecustomform() {
        $setting['formName'] = $this->security->xss_clean($this->input->post('form_name'));
        $setting['formData'] = $this->security->xss_clean($this->input->post('form_data'));
        $setting['created'] = time();
        $setting['isActive'] = 1;
        $this->db->insert('customeform', $setting);
        return TRUE;
    }

    public function updateform() {
        $formName = $this->security->xss_clean($this->input->post('form_name'));
        $formId = $this->security->xss_clean($this->input->post('editId'));
        if (trim($formName) != '') {
            $setting['formName'] = $formName;
        }
        $setting['formData'] = $this->security->xss_clean($this->input->post('form_data'));
        $this->db->where('formId', $formId);
        $this->db->update('customeform', $setting);
        return TRUE;
    }

    /* custome forms */

    public function getallForm() {
        $this->db->select('*');
        $this->db->from('customeform');
        $query = $this->db->get();
        return $query->result();
    }

    public function getForm($formId) {
        $this->db->select('*');
        $this->db->from('customeform');
        $this->db->where('formId', $formId);
        $query = $this->db->get();
        return $query->result();
    }

    public function getcommissionSetting() {
        $this->db->select('*');
        $this->db->from('setting_admin_commission');
        $query = $this->db->get();
        return $query->result();
    }

    public function deleteform($formId) {
        $this->db->where('formId', $formId);
        $this->db->delete('customeform');
        return true;
    }

    public function getallFroms() {
        $this->db->select('*');
        $this->db->from('customeform');
        $this->db->where('isActive', 1);
        $query = $this->db->get();
        return $query->result();
    }

    /* 	public function getform($formId){
      $this->db->select('*');
      $this->db->from('customeform');
      $this->db->where('isActive',1);
      $this->db->where('formId',$formId);
      $query = $this->db->get();
      return $query->result();
      } */

    // by raj
    public function adminDeleteAD($adId) {
        $ad['isDeleted'] = 1;
        $this->db->where('adId', $adId);
        $this->db->update('ad_info', $ad);
        return true;
    }

    public function adminStatusAD($adId, $currentStatus) {
        $ad['isActive'] = 1;
        if ($currentStatus == '1') {

            $ad['isActive'] = 0;
        } elseif ($currentStatus == '0') {

            $ad['isActive'] = 1;
        }

        $this->db->where('adId', $adId);
        $this->db->update('ad_info', $ad);
        return true;
    }

    public function getallLeads() {



        //$query = $this->db->query("SELECT * FROM user_profile,ad_form_data where ad_form_data.publisherId = user_profile.userId and isRoleback!=1 ORDER BY datetime DESC");
        $query = $this->db->query("Select Pub.userId as publisherid,Pub.userName as publisher_name,Adt.advertiserid as advertiserid,Adt.advertiser_name,Adt.form_data,Adt.datetime,Adt.ipaddress, Adt.category_name,Adt.state_name,Adt.adv_form_data_id as form_data_id,Adt.categoryId from 
(
 SELECT ad_form_data.publisherId,ad_form_data.form_data_id,user_profile.userId,user_profile.userName
 FROM user_profile, ad_form_data
 WHERE (ad_form_data.publisherId = user_profile.userId AND isRoleback !=1 )
) as Pub
INNER JOIN
(
 select Adt.* from (SELECT ad_form_data.form_data_id,ad_form_data.recomanded_advertiser ,user_profile.userId as advertiserid, user_profile.userName as advertiser_name,ad_form_data.form_data,ad_form_data.datetime,ad_form_data.ipaddress,ad_form_data.category_name, ad_form_data.state_name,ad_form_data.form_data_id as adv_form_data_id,ad_form_data.categoryId
 FROM user_profile, ad_form_data
 WHERE (ad_form_data.recomanded_advertiser = user_profile.userId AND isRoleback !=1 )) Adt
) Adt
ON Pub.form_data_id= Adt.form_data_id ORDER BY datetime DESC");
//        $publishers = $query->result();
        $res = $query->result_array();
//        $advertiser = $this->getLeadsAdvertiser();;
//        //print_r($publishers);
//        //print_r($advertiser);
//        $cnt = 0;
//        $dt = 0;
//        $res = array();
//        while ($cnt < count($publishers)) {
//            $tm = 0;
//
//            while ($tm < count($advertiser)) {
//                if ($publishers[$cnt]->form_data_id == $advertiser[$tm]->form_data_id) {
//                    $res[$dt]['advertiserid'] = $advertiser[$tm]->userId;
//                    $res[$dt]['advertiser_name'] = $advertiser[$tm]->userName;
//                    $res[$dt]['publisherid'] = $publishers[$cnt]->userId;
//                    $res[$dt]['publisher_name'] = $publishers[$cnt]->userName;
//                    $res[$dt]['form_data'] = $advertiser[$tm]->form_data;
//                    $res[$dt]['datetime'] = $advertiser[$tm]->datetime;
//                    $res[$dt]['ipaddress'] = $advertiser[$tm]->ipaddress;
//                    $res[$dt]['category_name'] = $advertiser[$tm]->category_name;
//                    $res[$dt]['state_name'] = $advertiser[$tm]->state_name;
//                    $res[$dt]['form_data_id'] = $advertiser[$tm]->form_data_id;
//                    $res[$dt]['categoryId'] = $advertiser[$tm]->categoryId;
//                    $dt++;
//                }
//                $tm++;
//            }
//            $cnt++;
//        }
        return $res;
    }

    public function getLeadsAdvertiser() {


        $query = $this->db->query("SELECT * FROM user_profile,ad_form_data where ad_form_data.recomanded_advertiser = user_profile.userId and isRoleback!=1");
        return $advertiser = $query->result();
    }

    public function getLeadsDetails($form_data_id) {
        $query = $this->db->query("SELECT form_data,categoryId FROM ad_form_data where form_data_id = $form_data_id");
        return $formdetails = $query->row();
    }

    public function rollbackLeads($form_data_id) {

        $this->db->where('form_data_id', $form_data_id);
        $this->db->delete('accounts');
        $ad['isRoleback'] = 1;
        $this->db->where('form_data_id', $form_data_id);
        $this->db->update('ad_form_data', $ad);
    }

    // end by raj


    public function getallcategories() {
        $this->db->select('*');
        $this->db->where('parentCategory', 0);
        $this->db->from('categories');
        $query = $this->db->get();
        return $res = $query->result();
    }

    public function getleadsviews() {
        $start = strtotime("first day of this month midnight");
        //     echo $start ." <br/>";
        $end = $start + 30 * 86400;
        //    echo $end;
        $query = $this->db->query("SELECT  *, COUNT(*) as views  FROM lead_form_views  INNER JOIN user_profile where user_profile.userId=lead_form_views.publisher_id AND isActive=1 AND isDeleted !=1 AND isAccepted =1 and datetime BETWEEN $start AND $end GROUP BY publisher_id ,category_id");
        return $res = $query->result();
    }

    public function getoldviews($start, $end) {
        $query = $this->db->query("SELECT  *, COUNT(*) as views  FROM lead_form_views  INNER JOIN user_profile where user_profile.userId=lead_form_views.publisher_id AND isActive=1 AND isDeleted !=1 AND isAccepted =1 and  datetime BETWEEN $start AND $end GROUP BY publisher_id ,category_id");
        return $res = $query->result();
    }

    public function gettotalViews() {
        $start = strtotime("first day of this month midnight");
        // echo $start ." <br/>";
        $end = $start + 30 * 86400;
        //echo $end;
        $query = $this->db->query("SELECT  *, COUNT(*) as views  FROM lead_form_views  INNER JOIN categories where categories.categoryId=lead_form_views.category_id and datetime BETWEEN $start AND $end GROUP BY category_id");
        return $res = $query->result();
    }

    public function getOldcatviews($start, $end) {
        $query = $this->db->query("SELECT  *, COUNT(*) as views  FROM lead_form_views  INNER JOIN categories where categories.categoryId=lead_form_views.category_id and datetime BETWEEN $start AND $end GROUP BY category_id");
        return $res = $query->result();
    }

    public function gettotalleads() {
        $start = strtotime("first day of this month midnight");
        // echo $start ." <br/>";
        $end = $start + 30 * 86400;
        //echo $end;
        $query = $this->db->query("SELECT  *, COUNT(*) as totalleads  FROM ad_form_data where isRoleback!=1 and datetime BETWEEN $start AND $end GROUP BY categoryId");
        //print_r($query) ;
        return $res = $query->result();
    }

    public function gettotaloldleads($start, $end) {
        $query = $this->db->query("SELECT  *, COUNT(*) as totalleads  FROM ad_form_data where isRoleback!=1 and datetime BETWEEN $start AND $end  GROUP BY categoryId");
        return $res = $query->result();
    }

    // by sarvesh
    public function getLeadalertSetting() {
        $this->db->select('*');
        $this->db->from('admin_info');
        $query = $this->db->get();
        return $res = $query->result();
    }

    public function getLeadalertupdate($data) {

        $this->db->update('admin_info', $data);
    }

    // end sarvesh
    //by sarvesh 27 feb 2015
    public function getautoreminder($start, $end) {
        if (!empty($start) && !empty($end)) {
            $query = $this->db->query("SELECT  * FROM auto_reminder where insurance_expiry_date BETWEEN $start AND $end order by id DESC");
            $res = $query->result();
        } else {
            $this->db->select('*');
            $this->db->from('auto_reminder');
            $this->db->order_by("id", "desc");
            $query = $this->db->get();
            $res = $query->result();
        }
        return $res;
    }

    public function getautoreminderbyid($id) {
        $this->db->select('*');
        $this->db->from('auto_reminder');
        $this->db->where('id', $id);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function updateprofileautoreminder($userid) {

        $u['name'] = $this->security->xss_clean($this->input->post('name'));
        $u['phone_number'] = $this->security->xss_clean($this->input->post('PhoneNumber'));
        $u['email'] = $this->security->xss_clean($this->input->post('email'));
        $u['current_insurance_status'] = $this->security->xss_clean($this->input->post('current_insurance_status'));
        $u['insurance_type'] = $this->security->xss_clean($this->input->post('insurance-type'));
        $userdate = $this->security->xss_clean($this->input->post('date'));
        $u['insurance_expiry_date'] = strtotime($userdate)+3600;


        //$query = $this->db->get();
        $this->db->where('id', $userid);
        return($this->db->update('auto_reminder', $u));
    }

    public function autoreminderdelete($id) {
        $this->db->where('id', $id);
        $this->db->delete('auto_reminder');
        return true;
    }

    public function getautoreminderforexport($start, $end, $insurance_type) {

        if (!empty($start) && !empty($end)) {
            $query = $this->db->query("SELECT  * FROM auto_reminder where insurance_type = '$insurance_type' AND insurance_expiry_date BETWEEN $start AND $end order by id DESC");
            $res = $query->result();
        } else {
            $this->db->select('*');
            $this->db->from('auto_reminder');
            $this->db->where('insurance_type', $insurance_type);
            $this->db->order_by("id", "desc");
            $query = $this->db->get();
            $res = $query->result();
        }
        return $res;
    }

    //end
}

?>