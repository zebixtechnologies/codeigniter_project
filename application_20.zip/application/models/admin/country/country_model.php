<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */
 
class country_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
  
    public function getallcountry(){
        $this->db->select('*');
		$query = $this->db->get('country');
		return $query->result();
    }
	public function getcountry($catId){
        $this->db->select('*');
		$this->db->where('countryId',$catId);
		$query = $this->db->get('country');
		return $query->result();
    }
	

	public function deleteCountry($catId){
		$this->db->where('countryId',$catId);
		return($this->db->delete('country')) ? true:false;
    }
	
	public function insertNewCountry(){
		$country_name 		= $this->security->xss_clean($this->input->post('country_name'));
		$country_val 	= $this->security->xss_clean($this->input->post('country_val'));
		$isActive 			= $this->security->xss_clean($this->input->post('isActive'));
		$this->db->select('*');
		$this->db->where('name',$country_name);
		$this->db->or_where('value',$country_val);
		$query = $this->db->get('country');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
			
			$cat['name'] 		= $country_name;
			$cat['value'] 		= $country_val;
			$cat['isActive']	= $isActive;
			$this->db->insert('country',$cat);
			return true;
		}
	}
	public function updateCountry(){
		$country_name 		= $this->security->xss_clean($this->input->post('country_name'));
		$country_val 	= $this->security->xss_clean($this->input->post('country_val'));
		$isActive 			= $this->security->xss_clean($this->input->post('isActive'));
		$editId 			= $this->security->xss_clean($this->input->post('editId'));
		$this->db->select('*');
		$this->db->where('name',$country_name);
		
		$this->db->where('countryId !=', $editId );
		$query = $this->db->get('country');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$cat['name'] 		= $country_name;
		$cat['value'] 		= $country_val;
		$cat['isActive']	= $isActive;
		$this->db->where('countryId',$editId);
		$this->db->update('country',$cat);
		return true;
		}
	}
}
?>