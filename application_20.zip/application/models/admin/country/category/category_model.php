<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */
 
class category_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
  
    public function getcategaryInfo($isActive){
        $this->db->select('*');
		//$this->db->where('parentCategory',$parentId);
		$this->db->where('isActive',$isActive);
		$query = $this->db->get('categories');
		return $query->result();
    }
	public function getcategary($catId){
        $this->db->select('*');
		$this->db->where('categoryId',$catId);
		$query = $this->db->get('categories');
		return $query->result();
    }
	public function subcategory($parentId){
        $this->db->select('*');
		$this->db->where('parentCategory',$parentId);
		$query = $this->db->get('categories');
		return $query->result();
    }
	public function getallcategary(){
        $this->db->select('c.*,c_dup.categoryName as parentName');
		$this->db->from('categories c');
		$this->db->group_by('categoryId');
		$this->db->join('categories c_dup','c_dup.categoryId=c.parentCategory','left outer');
		$query = $this->db->get();
		return $query->result();
    }
	public function deleteCategory($catId){
		$this->db->where('categoryId',$catId);
		$this->db->or_where('parentCategory',$catId);
		return($this->db->delete('categories')) ? true:false;
    }
	
	public function insertNewCategory(){
		$category_name 		= $this->security->xss_clean($this->input->post('category_name'));
		$parent_category 	= $this->security->xss_clean($this->input->post('parent_category'));
		$category_detail 	= $this->security->xss_clean($this->input->post('category_detail'));
		$isActive 			= $this->security->xss_clean($this->input->post('isActive'));
		$this->db->select('*');
		$this->db->where('categoryName',$category_name);
		$query = $this->db->get('categories');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$cat['categoryName'] 		= $category_name;
		$cat['categoryDescription'] = $category_detail;
		$cat['parentCategory']		= $parent_category;
		$cat['isActive']			= $isActive;
		$cat['created']			= time();
		$cat['lastUpdate']			= time();
		$this->db->insert('categories',$cat);
		return true;
		}
	}
	public function updateCategory(){
		$category_name 		= $this->security->xss_clean($this->input->post('category_name'));
		$parent_category 	= $this->security->xss_clean($this->input->post('parent_category'));
		$category_detail 	= $this->security->xss_clean($this->input->post('category_detail'));
		$isActive 			= $this->security->xss_clean($this->input->post('isActive'));
		$editId 			= $this->security->xss_clean($this->input->post('editId'));
		$this->db->select('*');
		$this->db->where('categoryName',$category_name);
		$this->db->where('categoryId !=', $editId );
		$query = $this->db->get('categories');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$cat['categoryName'] 		= $category_name;
		$cat['categoryDescription'] = $category_detail;
		$cat['parentCategory']		= $parent_category;
		$cat['isActive']			= $isActive;
		$cat['lastUpdate']			= time();
		
		$this->db->where('categoryId',$editId);
		$this->db->update('categories',$cat);
		
		return true;
		}
	}
}
?>