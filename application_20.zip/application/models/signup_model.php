<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */

class signup_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	
	public function usersignup()
	{
		$name = $this->security->xss_clean($this->input->post('name'));
		$company = $this->security->xss_clean($this->input->post('company'));
		$email 	= $this->security->xss_clean($this->input->post('email'));
		$categories	= $this->security->xss_clean($this->input->post('cateories'));
		 $cat=  implode('-',$categories);
		$phone=$this->security->xss_clean($this->input->post('phone'));
		$isActive='1';
		$this->db->select('*');
		$this->db->where('email',$email);
		$query = $this->db->get('user_profile');
		if($query->num_rows > 0){
			return false; // 2 for duplicate entry
		}else{
		$user['name'] = $category_name;
		$user['company'] = $category_detail;
		$user['website']= $parent_category;
		$user['isActive']= $isActive;
		$user['requesTime']= time();
		$user['categories']= $cat;
		$this->db->insert('user_profile',$user);
		return true;
		}
	}
	
	// sign in page accroding user role
	  public function validate(){
              //$this->load->library("session");
              //if(!isset($_SESSION)) 
              //session_start();
        // grab user input
        $username = $this->security->xss_clean($this->input->post('username'));
        $password = $this->security->xss_clean($this->input->post('password'));
        $remember = $this->security->xss_clean($this->input->post('remember'));
		$user	=	base64_encode($username);
		$pass	=	base64_encode($password);
		if($remember == 1){
			$this->input->set_cookie('username', $user, time() * 3600 * 24 * 365 );
			$this->input->set_cookie('password', $pass, time() * 3600 * 24 * 365 );
		}else{
			$this->input->set_cookie('username','', 0);
			$this->input->set_cookie('password', '', 0);
		}
        $this->db->where('userName', $username);
        $this->db->where('password', $password); 
        $this->db->where('isDeleted',0);
        $query = $this->db->get('user_profile');
        if($query->num_rows == 1)
        {
            $row = $query->row();
			if($row->isActive == 0){
				return 2; // user deactive by admin
			}
			if($row->isActive == 2){
				return 3; // user suspended by admin
			}
			$login_user = array(
                'user_id' 	=> $row->userId,
                'user_name' => $row->name,
                'last_login'=> $row->lastLogin,
                'user_type'=> $row->userType,
                'ip_address'=> $row->lastLoginIp,
                'user_image'=> $row->profilePic,
                );
            $this->session->set_userdata('user_logged_in',$login_user);
			 if($row->lastLogin !='' && $row->lastLoginIp !='' ) {
			 	$msg = '<div class="alert alert-info fade in">
                                  <a href="#" class="close" data-dismiss="alert"></a>
                                    <strong>Hello '.ucfirst($login_user['user_name']).'</strong><br>
                                    Your Last Login Time Is '.date("d F Y g:h:i",$login_user['last_login']).'<br/>
                                    And Last Login Ip '.$login_user['ip_address'].'<br/><a href="#">Click For More Info </a> </div>';
			 } else {
			 $msg = '<div class="alert alert-info fade in">
                                    <a href="#" class="close" data-dismiss="alert"></a>
                                    <strong>Hello '.ucfirst($login_user['user_name']).'</strong><br>
                                    	Welcome To '. SITE_NAME .'! Here you can manage your ad campaigns.
									 </div>';	
			 }
			 
              $this->session->set_flashdata('user_message',$msg);
            
			$id 				= $login_user['user_id'];
            $user_up['lastLogin'] 	= time();
            $user_up['lastLoginIp']= $_SERVER['REMOTE_ADDR'];
            $this->db->where('userId', $id);
            $this->db->update('user_profile', $user_up); 
            //print_r( $this->session->all_userdata());
            return ($row->userType == 1) ? 8:9; // 8 for advertiser 9 for publisher
        }
       // user name pass not match
        return 0;
    }
	public function getparentcategaryInfo(){
		$this->db->select('*');
		$this->db->from('categories');
		$this->db->where('parentCategory',0);
                $this->db->where('isActive',1);
		$this->db->order_by('categoryName');
		$query = $this->db->get();
		return $query->result();
		
	}
	public function inserUserDetail(){
	
		$u['company']	 	= $this->security->xss_clean($this->input->post('company_name'));
		$u['name']	 		= $this->security->xss_clean($this->input->post('name'));
		$u['userName']	    = $this->security->xss_clean($this->input->post('user_name'));
		$u['email']	    	= $this->security->xss_clean($this->input->post('email'));
		$u['phone']	    	= $this->security->xss_clean($this->input->post('phone'));
		$u['website']	    = $this->security->xss_clean($this->input->post('website'));
		$u['userType']	    = $this->security->xss_clean($this->input->post('userType'));
			
			if(empty($_POST['category'])){
				return 4; // choose category
			}else{
                            // if advertiser then
                            if($u['userType'] == "1"){
                                $this->db->select("categoryId,minbidprice");
                                $query = $this->db->get("categories");
                                $cats = $query->result();
                                $allCatPriceArr = array();
                                $bstring4BidPrice = "";
                                $commaBid = "";
                                foreach($cats as $cat){
                                    $allCatPriceArr[$cat->categoryId] = $cat->minbidprice;
                                }
                                foreach($_POST['category'] as $cat){
                                    $bstring4BidPrice .= $commaBid . $cat . ":" . $allCatPriceArr[$cat];
                                    $commaBid = ",";
                                }
                                $u["bidprice"] = $bstring4BidPrice;
                                $u["activecategory"] = $bstring4BidPrice;
                            }
				$counts = count($_POST['category']);
					$cat = array();
					for($j=0;$j<$counts;$j++){
						$cat[$j] = $_POST['category'][$j];
					}
				$u['categoryId']	 = implode('-',$cat);
			}
			
		$u['requesTime']	 = time();
		$u['isActive']	     = 1;
		$u['isDeleted']	     = 0;
		/*$this->db->select('email,userName');
		$this->db->from('user_profile');
		$this->db->where('email',$u['email']);
		$this->db->where('isDeleted',0);
		$this->db->or_where('userName',$u['userName']);
		
		*/
		
		$query=$this->db->query("SELECT email,userName from user_profile where (email='".$u['email']."' and isDeleted=0 and isAccepted!=2 ) or (userName='".$u['userName']."' and isDeleted=0 and isAccepted!=2)");
		//$query = $this->db->get();
		if($query->num_rows == 1){
			$row = $query->row();
			if($row->userName == $u['userName']){
				return 2; // duplicate username
			}
			if($row->email == $u['email']){
				 return 3; // duplicate email
				
			}
		}else{
			
			$this->db->insert('user_profile',$u);
			return $this->db->insert_id();; // added successfully
			// return $u['categoryId'];
			
		}
		
	}
	
	public function checkMail(){
	$email = $this->security->xss_clean($this->input->post('useremail'));
		$this->db->select('*');
		$this->db->from('user_profile');
		$this->db->where('email',$email);
		$query = $this->db->get();
                //echo $this->db->last_query();
		//if($query->num_rows == 1){
			return $query->result();
		//}else{
		//return false;
		//}
		
	}
	
	
	public function getAdFOrm($adId){
		$this->db->select('a_i.*,cf.*,u_p.adverFromIcon');
		$this->db->from('ad_info a_i');
		$this->db->join('customeform cf','cf.formId =a_i.formId');
		$this->db->join('user_profile u_p','a_i.userId =u_p.userId');
		$this->db->where('a_i.adId',$adId);
		$query = $this->db->get();
		return $query->result();
	}
	
	public function getAllAds(){
		$this->db->select('a_i.*');
		$this->db->from('ad_info a_i');
		$this->db->where('a_i.isApproved',1);
		$this->db->where('a_i.isDeleted',0);
		$this->db->where('a_i.isActive',1);
		$this->db->where('a_i.userActivation',1);
		// some conditions remaining like state , publisher
		$this->db->order_by('a_i.bid_ppc','desc');
		$query = $this->db->get();
		return $query->result();
	}
	
	public function updateview($keep_ad_ids,$statecode=null,$search=null,$zipcode=null){
		$REF = array();
		foreach($keep_ad_ids as $key=>$value){
			$status['isViewed']	=	1;
			$status['adId']		=	$value;
			$status['ipaddress']=	$_SERVER['REMOTE_ADDR'];
			$status['created']=	time();
			$this->db->insert('ad_status',$status);
		$REF[$value] = $this->db->insert_id();
		}
	}
	
	public function getuserInfo($userId){
			$this->db->select('*');
			$this->db->from('user_profile');
			$this->db->where('userId',$userId);
			$query = $this->db->get();
			return $query->result();
		}
}