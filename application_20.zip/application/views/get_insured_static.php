 <script type="text/javascript">
  $(document).ready(function(){
     $('body').removeClass('homeindex');
  });
</script>
<!-- content--> 
    <div class="container dotted-back">
        <div class="row clearfix bgbroker">	
            <div class="broker">
                <div class="cols clearfix">
                    <div class="col3">
                        Auto Insurance
                        <div class="insured">
                           <form id="form1" name="form1" method="get" action="http://www.keyverticals.com/autoform.html"  >
                               <div class="block">
                                  <span>YOUR STATE: </span>
                                  <select id="state" name="statecode"><option value="Lagos">Lagos</option><option value="Abia">Abia</option><option value="Abuja">Abuja</option><option value="Adamawa">Adamawa</option><option value="Akwa Ibom">Akwa Ibom</option><option value="Anambra">Anambra</option><option value="Bauchi">Bauchi</option><option value="Bayelsa">Bayelsa</option><option value="Benue">Benue</option><option value="Borno">Borno</option><option value="Cross River">Cross River</option><option value="Delta">Delta</option><option value="Ebonyi">Ebonyi</option><option value="Edo">Edo</option><option value="Ekiti">Ekiti</option><option value="Enugu">Enugu</option><option value="Gombe">Gombe</option><option value="Imo">Imo</option><option value="Jigawa">Jigawa</option><option value="Kaduna">Kaduna</option><option value="Kano">Kano</option><option value="Katsina">Katsina</option><option value="Kebbi">Kebbi</option><option value="Kogi">Kogi</option><option value="Kwara">Kwara</option><option value="Nasarawa">Nasarawa</option><option value="Niger">Niger</option><option value="Ogun">Ogun</option><option value="Ondo">Ondo</option><option value="Osun">Osun</option><option value="Oyo">Oyo</option><option value="Plateau">Plateau</option><option value="Rivers">Rivers</option><option value="Sokoto">Sokoto</option><option value="Taraba">Taraba</option><option value="Yobe">Yobe</option><option value="Zamfara">Zamfara</option></select>
                               </div>
                               <div class="block">
                                <span>INSURANCE TYPE:</span>  
                                <select name="select2" id="insurancepp"  value="GO">
                                     <option value="http://www.keyverticals.com/autoform.html">Auto Insurance </option>
                                </select>
                               </div>
                             <div class="block clearfix">
                                 <input type="image" class="quote_btn" name="imageField" src="../assets/user/design/images/submitGetInsurence.png" id="button" value="submit"/>
                               </div>
                            </form> 
                        </div>
                    </div>
                     <div class="col3">
                        Business Insurance
                        <div class="insured">
                            <form id="form1" name="form1" method="get" action="http://www.keyverticals.com/businessform.html"  >
                                <div class="block">
                                    <span>YOUR STATE: </span>
                                    <select id="state" name="statecode"><option value="Lagos">Lagos</option><option value="Abia">Abia</option><option value="Abuja">Abuja</option><option value="Adamawa">Adamawa</option><option value="Akwa Ibom">Akwa Ibom</option><option value="Anambra">Anambra</option><option value="Bauchi">Bauchi</option><option value="Bayelsa">Bayelsa</option><option value="Benue">Benue</option><option value="Borno">Borno</option><option value="Cross River">Cross River</option><option value="Delta">Delta</option><option value="Ebonyi">Ebonyi</option><option value="Edo">Edo</option><option value="Ekiti">Ekiti</option><option value="Enugu">Enugu</option><option value="Gombe">Gombe</option><option value="Imo">Imo</option><option value="Jigawa">Jigawa</option><option value="Kaduna">Kaduna</option><option value="Kano">Kano</option><option value="Katsina">Katsina</option><option value="Kebbi">Kebbi</option><option value="Kogi">Kogi</option><option value="Kwara">Kwara</option><option value="Nasarawa">Nasarawa</option><option value="Niger">Niger</option><option value="Ogun">Ogun</option><option value="Ondo">Ondo</option><option value="Osun">Osun</option><option value="Oyo">Oyo</option><option value="Plateau">Plateau</option><option value="Rivers">Rivers</option><option value="Sokoto">Sokoto</option><option value="Taraba">Taraba</option><option value="Yobe">Yobe</option><option value="Zamfara">Zamfara</option></select>
                                </div>
                                <div class="block">
                                    <span>INSURANCE TYPE:</span> 
                                    <select name="select2" id="insurancepp"  value="GO"><option value="http://www.keyverticals.com/businessform.html">Business Insurance</option></select>
                                </div>  
                                <div class="block clearfix">
                                 <input type="image" class="quote_btn" name="imageField" src="../assets/user/design/images/submitGetInsurence.png" id="button" value="submit"/>
                               </div>
                            </form>
                        </div>
                    </div>
                     <div class="col3">
                        Home Insurance
                        <div class="insured">
                            <form id="form1" name="form1" method="get" action="http://www.keyverticals.com/homeform.html"  >
                                <div class="block">
                                    <span>YOUR STATE: </span>
                                        <select id="state" name="statecode"><option value="Lagos">Lagos</option><option value="Abia">Abia</option><option value="Abuja">Abuja</option><option value="Adamawa">Adamawa</option><option value="Akwa Ibom">Akwa Ibom</option><option value="Anambra">Anambra</option><option value="Bauchi">Bauchi</option><option value="Bayelsa">Bayelsa</option><option value="Benue">Benue</option><option value="Borno">Borno</option><option value="Cross River">Cross River</option><option value="Delta">Delta</option><option value="Ebonyi">Ebonyi</option><option value="Edo">Edo</option><option value="Ekiti">Ekiti</option><option value="Enugu">Enugu</option><option value="Gombe">Gombe</option><option value="Imo">Imo</option><option value="Jigawa">Jigawa</option><option value="Kaduna">Kaduna</option><option value="Kano">Kano</option><option value="Katsina">Katsina</option><option value="Kebbi">Kebbi</option><option value="Kogi">Kogi</option><option value="Kwara">Kwara</option><option value="Nasarawa">Nasarawa</option><option value="Niger">Niger</option><option value="Ogun">Ogun</option><option value="Ondo">Ondo</option><option value="Osun">Osun</option><option value="Oyo">Oyo</option><option value="Plateau">Plateau</option><option value="Rivers">Rivers</option><option value="Sokoto">Sokoto</option><option value="Taraba">Taraba</option><option value="Yobe">Yobe</option><option value="Zamfara">Zamfara</option></select>
                                </div>
                                <div class="block">
                                    <span>INSURANCE TYPE:</span></td>
                                    <select name="select2" id="insurancepp"  value="GO"><option value="http://www.keyverticals.com/homeform.html" >Home Insurance</option></select>
                                </div>    
                               <div class="block clearfix">
                                 <input type="image" class="quote_btn" name="imageField" src="../assets/user/design/images/submitGetInsurence.png" id="button" value="submit"/>
                               </div>
                            </form>  
                        </div>
                    </div>
                </div>
                <div class="cols clearfix">
                    <div class="col3">
                        Life Insurance
                        <div class="insured">
                            <form id="form1" name="form1" method="get" action="http://www.keyverticals.com/lifeform.html"  >
                                <div class="block">
                                    <span>YOUR STATE: </span>
                                    <select id="state" name="statecode"><option value="Lagos">Lagos</option><option value="Abia">Abia</option><option value="Abuja">Abuja</option><option value="Adamawa">Adamawa</option><option value="Akwa Ibom">Akwa Ibom</option><option value="Anambra">Anambra</option><option value="Bauchi">Bauchi</option><option value="Bayelsa">Bayelsa</option><option value="Benue">Benue</option><option value="Borno">Borno</option><option value="Cross River">Cross River</option><option value="Delta">Delta</option><option value="Ebonyi">Ebonyi</option><option value="Edo">Edo</option><option value="Ekiti">Ekiti</option><option value="Enugu">Enugu</option><option value="Gombe">Gombe</option><option value="Imo">Imo</option><option value="Jigawa">Jigawa</option><option value="Kaduna">Kaduna</option><option value="Kano">Kano</option><option value="Katsina">Katsina</option><option value="Kebbi">Kebbi</option><option value="Kogi">Kogi</option><option value="Kwara">Kwara</option><option value="Nasarawa">Nasarawa</option><option value="Niger">Niger</option><option value="Ogun">Ogun</option><option value="Ondo">Ondo</option><option value="Osun">Osun</option><option value="Oyo">Oyo</option><option value="Plateau">Plateau</option><option value="Rivers">Rivers</option><option value="Sokoto">Sokoto</option><option value="Taraba">Taraba</option><option value="Yobe">Yobe</option><option value="Zamfara">Zamfara</option></select>
                                </div>
                                <div class="block">
                                    <span>INSURANCE TYPE:</span>
                                    <select name="select2" id="insurancepp"  value="GO"><option value="http://www.keyverticals.com/lifeform.html">Life Insurance </option></select>
                                </div>
                               <div class="block clearfix">
                                 <input type="image" class="quote_btn" name="imageField" src="../assets/user/design/images/submitGetInsurence.png" id="button" value="submit"/>
                               </div>
                            </form>
                        </div>
                    </div>
                     <div class="col3">
                        Health Insurance
                        <div class="insured">
                            <form id="form1" name="form1" method="get" action="http://www.keyverticals.com/healthform.html"  >
                                <div class="block"> 
                                    <span>YOUR STATE: </span></td>
                                    <select id="state" name="statecode"><option value="Lagos">Lagos</option><option value="Abia">Abia</option><option value="Abuja">Abuja</option><option value="Adamawa">Adamawa</option><option value="Akwa Ibom">Akwa Ibom</option><option value="Anambra">Anambra</option><option value="Bauchi">Bauchi</option><option value="Bayelsa">Bayelsa</option><option value="Benue">Benue</option><option value="Borno">Borno</option><option value="Cross River">Cross River</option><option value="Delta">Delta</option><option value="Ebonyi">Ebonyi</option><option value="Edo">Edo</option><option value="Ekiti">Ekiti</option><option value="Enugu">Enugu</option><option value="Gombe">Gombe</option><option value="Imo">Imo</option><option value="Jigawa">Jigawa</option><option value="Kaduna">Kaduna</option><option value="Kano">Kano</option><option value="Katsina">Katsina</option><option value="Kebbi">Kebbi</option><option value="Kogi">Kogi</option><option value="Kwara">Kwara</option><option value="Nasarawa">Nasarawa</option><option value="Niger">Niger</option><option value="Ogun">Ogun</option><option value="Ondo">Ondo</option><option value="Osun">Osun</option><option value="Oyo">Oyo</option><option value="Plateau">Plateau</option><option value="Rivers">Rivers</option><option value="Sokoto">Sokoto</option><option value="Taraba">Taraba</option><option value="Yobe">Yobe</option><option value="Zamfara">Zamfara</option></select>
                                </div>  
                                 <div class="block">
                                    <span>INSURANCE TYPE:</span>
                                    <select name="select2" id="insurancepp"  value="GO"><option value="http://www.keyverticals.com/healthform.html">Health Insurance</option> </select>
                                </div>
                               <div class="block clearfix">
                                 <input type="image" class="quote_btn" name="imageField" src="../assets/user/design/images/submitGetInsurence.png" id="button" value="submit"/>
                               </div>
                            </form>
                        </div>
                    </div>
                     <div class="col3">
                        Travel Insurance
                        <div class="insured">
                            <form id="form1" name="form1" method="get" action="http://www.keyverticals.com/travelform.html" >
                                <div class="block">
                                    <span>YOUR STATE: </span>
                                       <select id="state" name="statecode"><option value="Lagos">Lagos</option><option value="Abia">Abia</option><option value="Abuja">Abuja</option><option value="Adamawa">Adamawa</option><option value="Akwa Ibom">Akwa Ibom</option><option value="Anambra">Anambra</option><option value="Bauchi">Bauchi</option><option value="Bayelsa">Bayelsa</option><option value="Benue">Benue</option><option value="Borno">Borno</option><option value="Cross River">Cross River</option><option value="Delta">Delta</option><option value="Ebonyi">Ebonyi</option><option value="Edo">Edo</option><option value="Ekiti">Ekiti</option><option value="Enugu">Enugu</option><option value="Gombe">Gombe</option><option value="Imo">Imo</option><option value="Jigawa">Jigawa</option><option value="Kaduna">Kaduna</option><option value="Kano">Kano</option><option value="Katsina">Katsina</option><option value="Kebbi">Kebbi</option><option value="Kogi">Kogi</option><option value="Kwara">Kwara</option><option value="Nasarawa">Nasarawa</option><option value="Niger">Niger</option><option value="Ogun">Ogun</option><option value="Ondo">Ondo</option><option value="Osun">Osun</option><option value="Oyo">Oyo</option><option value="Plateau">Plateau</option><option value="Rivers">Rivers</option><option value="Sokoto">Sokoto</option><option value="Taraba">Taraba</option><option value="Yobe">Yobe</option><option value="Zamfara">Zamfara</option></select>
                                </div>
                                 <div class="block">
                                       <span>INSURANCE TYPE:</span> 
                                       <select name="select2" id="insurancepp"  value="GO"><option value="http://www.keyverticals.com/travelform.html">Travel Insurance</option></select>
                                 </div>
                                <div class="block clearfix">
                                 <input type="image" class="quote_btn" name="imageField" src="../assets/user/design/images/submitGetInsurence.png" id="button" value="submit"/>
                               </div>

                            </form>
                        </div>
                    </div>
                </div>

            </div>   
        </div>
     </div>        
<!-- content--> 


<script>
	$(document).ready(function(){
		$('.getinsured').addClass('active');
		
	})
</script>