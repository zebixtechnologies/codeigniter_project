<style>
body {
background: rgba(35, 107, 141, 0.87);
}
.container {
margin: 0 auto 0px auto;
overflow: auto;
width: 800px;
background:#fff;
box-shadow: 0px 1px 9px #fff;
border-radius:5px;
min-height:650px;
}	

.header{
border-bottom: 4px solid #2F83D3;
}
.header h1 {
background: url(http://www.keyverticals.com/assets/user/design/images/logo.png) no-repeat;
height: 81px !important;
margin: 18px 0 0 20px;
width: 350px;
}
.row{
padding:124px;
}
.content{
text-align:right;
margin:10px 0px;
padding:3em;
}
.thanks{
margin:5em 0px 0px;
padding:10px;
}
h2{
    margin: 10px;
    padding: 0px;
    text-align: center;
    color: #2F83D3;
    font-family: arial;
    font-size: 15pt;
}
</style>
<div class="container dotted-back">
    <div class="header">
    <h1></h1>
    </div>
    <div>
        <h2><?=$msg;?></h2>
    </div>
</div>
