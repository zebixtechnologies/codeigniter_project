<script type="text/javascript">
  $(document).ready(function(){
     $('body').removeClass('homeindex');
  });
</script>
 <div id="nav_current_back" class="clearfix">
	<div class="navsubheader row">
		<nav id="nav_current" class="products twelvecol last">
					<a class="active" href="about.html"><span class="arrow"></span>Our Company</a>
                    <a href="HowKeyVerticalsWorks.html">How KeyVerticals Works</a>
                    <a href="OurReportingPlatform.html">Our Reporting Platform</a>
                    <a href="DataReporting.html">Data Reporting</a>
                    <a href="HighlyFocusedSource.html">Highly Focused Source</a>
				</nav>
	</div>
</div>
       

<div class="container dotted-back">
	 <!-- content--> 
		<div class="container dotted-back">
			<div class="row clearfix">
				<h1 class="pagehead"><?=$page_name;?></h1>
               <?=str_replace('{base_uel}',$page);?>
    </div>
  </div>        
        <!-- content--> 
</div>